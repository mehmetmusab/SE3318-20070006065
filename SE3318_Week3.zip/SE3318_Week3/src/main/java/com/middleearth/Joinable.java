package com.middleearth;

/**
 * Interface for any entity that can join a quest.
 */
public interface Joinable {
    void joinQuest(Quest quest);
}
