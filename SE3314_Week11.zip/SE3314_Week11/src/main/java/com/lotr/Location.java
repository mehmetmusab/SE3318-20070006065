package com.lotr;

import java.util.HashMap;
import java.util.Map;

/**
 * Represents a location in Middle-Earth and provides navigation.
 */
public class Location {
    /**
     * Name of the location (e.g., Shire, Mordor).
     */
    private String name;

    /**
     * Map of neighboring locations and the routes.
     */
    private Map<Location, String> routes;

    /**
     * Constructs a new Location.
     * 
     * @param name name of location (non-null, non-empty)
     * @throws IllegalArgumentException if name invalid
     */
    public Location(final String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Invalid name for Location");
        }
        this.name = name;
        this.routes = new HashMap<>();
    }

    /**
     * Gets the name of this location.
     * 
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Adds a route from this location to another.
     * 
     * @param destination other location (non-null)
     * @param routeName   description of route (non-null, non-empty)
     * @throws IllegalArgumentException if parameters invalid
     */
    public void addRoute(final Location destination, final String routeName) {
        if (destination == null || routeName == null || routeName.isEmpty()) {
            throw new IllegalArgumentException("Invalid route parameters");
        }
        routes.put(destination, routeName);
    }

    /**
     * Gets the route name to a neighboring location.
     * 
     * @param destination other location (non-null)
     * @return route name or null if no route
     * @throws IllegalArgumentException if destination null
     */
    public String getRouteTo(final Location destination) {
        if (destination == null) {
            throw new IllegalArgumentException("Destination cannot be null");
        }
        return routes.get(destination);
    }
}
