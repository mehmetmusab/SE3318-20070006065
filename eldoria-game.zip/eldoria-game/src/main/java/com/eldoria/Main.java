package com.eldoria;

public class Main {
    public static void main(String[] args) {
        Mage gandalf = new Mage("Gandalf", 50);
        Warrior aragorn = new Warrior("Aragorn", 45);
        Enemy orc = new Enemy("Orc", 30);

        QuestBoard questBoard = new QuestBoard();
        questBoard.assignQuest(gandalf, "Defeat the Shadowlord");
        questBoard.assignQuest(aragorn, "Protect the village");

        BattleManager battleManager = new BattleManager();
        battleManager.battle(aragorn, orc);

        gandalf.castSpell();
        aragorn.attack();
    }
}
