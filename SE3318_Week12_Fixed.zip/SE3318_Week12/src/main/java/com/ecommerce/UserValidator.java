package com.ecommerce;

/**
 * Validates user information during registration.
 */
public class UserValidator {

    /**
     * Validate user details.
     * requires: username != null && !username.trim().isEmpty(), email != null && !email.trim().isEmpty() && contains '@'
     * @return true if valid, otherwise throws IllegalArgumentException
     */
    public static boolean validateUser(String username, String email) {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username must be non-null and non-empty");
        }
        if (email == null || email.trim().isEmpty() || !email.contains("@")) {
            throw new IllegalArgumentException("Email must be non-null, non-empty, and contain '@'");
        }
        // Simulate additional checks like uniqueness, domain validation, etc.
        return true;
    }
}
