package com.lotr;

import org.junit.Assert;
import org.junit.Test;

/**
 * Smoke tests for Character class.
 */
public class CharacterTest {

    @Test
    public void testCreateValidCharacter() {
        Character c = new Character("Legolas", "Elf", 2931, "Archer");
        Assert.assertEquals("Legolas", c.getName());
        Assert.assertEquals("Elf", c.getRace());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateInvalidCharacter() {
        new Character("", "Hobbit", -1, "");
    }
}
