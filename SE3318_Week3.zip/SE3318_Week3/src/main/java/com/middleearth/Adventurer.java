package com.middleearth;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents an Adventurer who can join quests.
 */
public class Adventurer extends Character implements Joinable {
    private String race;
    private List<Quest> quests;

    public Adventurer(String name, String race) {
        super(name, null);
        this.race = race;
        this.quests = new ArrayList<>();
    }

    public String getRace() {
        return race;
    }

    public List<Quest> getQuests() {
        return quests;
    }

    @Override
    public void joinQuest(Quest quest) {
        if (quest != null && !quests.contains(quest)) {
            quests.add(quest);
            quest.addAdventurer(this);
        }
    }

    public void listQuests() {
        System.out.println("Quests for adventurer '" + getName() + "':");
        for (Quest q : quests) {
            System.out.println("- " + q.getName() + " (Difficulty: " + q.getDifficultyLevel() + ")");
        }
    }
}
