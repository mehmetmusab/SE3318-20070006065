package com.hogwarts;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class DuelTest {

    private HogwartsStudent harry;
    private HogwartsStudent draco;

    @Before
    public void setUp() {
        harry = new HogwartsStudent("Harry", "Gryffindor", 3);
        draco = new HogwartsStudent("Draco", "Slytherin", 3);
    }

    @Test
    public void testDuelNeitherKnows() {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));
        Duel.start(harry, draco, "UnknownSpell");
        String result = out.toString().trim();
        Assert.assertTrue(result.contains("draw") || result.toLowerCase().contains("draw"));
    }

    @Test
    public void testDuelOneKnows() {
        harry.learnSpell("Lumos");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));
        Duel.start(harry, draco, "Lumos");
        String result = out.toString().trim();
        Assert.assertTrue(result.contains("harry") || result.contains("Harry"));
    }

    @Test
    public void testDuelBothKnow() {
        harry.learnSpell("Accio");
        draco.learnSpell("Accio");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));
        Duel.start(harry, draco, "Accio");
        String result = out.toString().trim();
        Assert.assertTrue(result.contains("wins") || result.contains("tie"));
    }
}
