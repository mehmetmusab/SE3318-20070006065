package com.lotr;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * Smoke tests for Location class.
 */
public class LocationTest {

    private Location loc1;
    private Location loc2;

    @Before
    public void setUp() {
        loc1 = new Location("Mordor");
        loc2 = new Location("Rohan");
    }

    @Test
    public void testAddAndRetrieveRoute() {
        loc1.addRoute(loc2, "Black Gate");
        Assert.assertEquals("Black Gate", loc1.getRouteTo(loc2));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddRouteInvalid() {
        loc1.addRoute(null, "");
    }
}
