package com.ecommerce;

public class App {
    public static void main(String[] args) {
        // Simulate user registration
        try {
            UserValidator.validateUser(null, "user@example.com");
        } catch (IllegalArgumentException e) {
            System.out.println("User validation failed: " + e.getMessage());
        }

        try {
            UserValidator.validateUser("john_doe", "");
        } catch (IllegalArgumentException e) {
            System.out.println("User validation failed: " + e.getMessage());
        }

        // Valid user
        try {
            if (UserValidator.validateUser("john_doe", "john@example.com")) {
                System.out.println("User 'john_doe' registered successfully.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("User validation failed: " + e.getMessage());
        }

        // Process an order
        OrderProcessor processor = new OrderProcessor();
        // Null order case
        try {
            processor.processOrder(null);
        } catch (IllegalArgumentException e) {
            System.out.println("Order processing error: " + e.getMessage());
        }

        // Invalid order with zero quantity
        try {
            Order order = new Order(123, "Widget", 0);
            processor.processOrder(order);
        } catch (IllegalArgumentException e) {
            System.out.println("Order processing error: " + e.getMessage());
        }

        // Valid order
        try {
            Order validOrder = new Order(124, "Gadget", 5);
            processor.processOrder(validOrder);
        } catch (IllegalArgumentException e) {
            System.out.println("Order processing error: " + e.getMessage());
        }

        // Handle payment
        PaymentService paymentService = new PaymentService();
        try {
            paymentService.processPayment(null, 100.0);
        } catch (IllegalArgumentException e) {
            System.out.println("Payment error: " + e.getMessage());
        }

        try {
            paymentService.processPayment("john_doe", -50.0);
        } catch (IllegalArgumentException e) {
            System.out.println("Payment error: " + e.getMessage());
        }

        // Valid payment
        try {
            if (paymentService.processPayment("john_doe", 150.0)) {
                System.out.println("Payment successful for user john_doe.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Payment error: " + e.getMessage());
        }
    }
}
