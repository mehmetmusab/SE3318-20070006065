package com.lotr;

/**
 * Main application to simulate interactions.
 */
public final class MainApp {
    /**
     * Prevent instantiation.
     */
    private MainApp() {
        // Utility class
    }

    /**
     * Main entry point.
     * 
     * @param args command-line arguments
     */
    public static void main(final String[] args) {
        // Locations
        Location shire = new Location("Shire");
        Location rivendell = new Location("Rivendell");
        shire.addRoute(rivendell, "Forest Path");

        // Characters
        Character frodo = new Character("Frodo Baggins", "Hobbit", 50,
                "Ring-bearer");
        Character aragorn = new Character("Aragorn", "Man", 87,
                "King of Gondor");

        // Quest
        Quest destroyRing = new Quest("Destroy the Ring", 10);
        destroyRing.addParticipant(frodo);
        destroyRing.addParticipant(aragorn);

        // Demonstration outputs
        System.out.println("Route from Shire to Rivendell: "
                + shire.getRouteTo(rivendell));
        System.out.println("Quest Type: " + destroyRing.getType());
        System.out.println("Participants: ");
        for (Character c : destroyRing.listParticipants()) {
            System.out.println("- " + c.getName() + ", age: " + c.getAge());
        }
    }
}
