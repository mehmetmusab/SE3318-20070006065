package com.eldoria;

public class BattleManager {
    public void battle(Hero hero, Enemy enemy) {
        System.out.println("Battle starts between " + hero.getName() + " (Level " + hero.getLevel() + ") and " +
            enemy.getName() + " (Level " + enemy.getLevel() + ").");

        // Simple simulated battle
        hero.speak();
        enemy.speak();
        System.out.println(hero.getName() + " attacks " + enemy.getName() + " for 15 damage.");
        System.out.println(enemy.getName() + " attacks " + hero.getName() + " for 10 damage.");
        System.out.println("The battle has ended.");
    }
}
