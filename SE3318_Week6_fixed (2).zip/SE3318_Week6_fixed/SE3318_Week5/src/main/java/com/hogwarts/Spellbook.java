package com.hogwarts;

import java.util.ArrayList;
import java.util.List;

/**
 * Stores a list of all spells.
 */
public class Spellbook {
    private List<String> spells;

    /**
     * Construct a new spellbook.
     * effects: initializes with empty spells list.
     */
    public Spellbook() {
        spells = new ArrayList<>();
    }

    /**
     * Add a spell to the book.
     * requires: spell != null
     * effects: adds spell to list
     * @param spell the spell to add
     */
    public void addSpell(String spell) {
        if (spell == null) {
            throw new IllegalArgumentException("Spell cannot be null.");
        }
        spells.add(spell);
    }

    /**
     * Retrieve a spell by index.
     * requires: index >= 0 and index < spells.size()
     * @param index position of spell
     * @return spell at index
     */
    public String getSpell(int index) {
        if (index < 0 || index >= spells.size()) {
            throw new IndexOutOfBoundsException("Invalid index.");
        }
        return spells.get(index);
    }

    /**
     * Return spells starting with a specific prefix.
     * requires: prefix != null
     * @param prefix prefix to match
     * @return list of matching spells
     */
    public List<String> getSpellsByPrefix(String prefix) {
        if (prefix == null) {
            throw new IllegalArgumentException("Prefix cannot be null.");
        }
        List<String> result = new ArrayList<>();
        for (String spell : spells) {
            if (spell.startsWith(prefix)) {
                result.add(spell);
            }
        }
        return result;
    }

    public List<String> getAllSpells() {
        return spells;
    }
}
