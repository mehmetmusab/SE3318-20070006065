package com.hogwarts;

import java.util.HashSet;
import java.util.Set;

/**
 * Represents a Hogwarts student.
 * requires: name != null, house != null, year > 0.
 * effects: initializes student with no known spells.
 */
public class HogwartsStudent {
    private String name;
    private String house;
    private int year;
    private Set<String> spellsLearned;

    /**
     * Construct a new student.
     * @param name the student's name, not null
     * @param house the student's house, not null
     * @param year the student's year, > 0
     * requires: name != null, house != null, year > 0
     * effects: creates student with empty spellsLearned
     */
    public HogwartsStudent(String name, String house, int year) {
        if (name == null || house == null || year <= 0) {
            throw new IllegalArgumentException("Invalid student parameters.");
        }
        this.name = name;
        this.house = house;
        this.year = year;
        this.spellsLearned = new HashSet<>();
    }

    /**
     * Student learns a new spell.
     * requires: spell != null
     * effects: if spell not already known, adds to spellsLearned and returns true; otherwise returns false.
     * @param spell the spell name, not null
     * @return true if added, false otherwise
     */
    public boolean learnSpell(String spell) {
        if (spell == null) {
            return false;
        }
        return spellsLearned.add(spell);
    }

    /**
     * Checks if student knows a spell.
     * requires: spell != null
     * @param spell the spell name
     * @return true if known, false otherwise
     */
    public boolean knowsSpell(String spell) {
        if (spell == null) {
            return false;
        }
        return spellsLearned.contains(spell);
    }

    public String getName() {
        return name;
    }

    public String getHouse() {
        return house;
    }

    public int getYear() {
        return year;
    }

    public Set<String> getSpellsLearned() {
        return spellsLearned;
    }

    @Override
    public String toString() {
        return "HogwartsStudent{" +
                "name='" + name + '\'' +
                ", house='" + house + '\'' +
                ", year=" + year +
                ", spellsLearned=" + spellsLearned +
                '}';
    }
}
