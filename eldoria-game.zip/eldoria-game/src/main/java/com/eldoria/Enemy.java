package com.eldoria;

public class Enemy extends Character {
    public Enemy(String name, int level) {
        super(name, level);
    }

    @Override
    public void speak() {
        System.out.println(name + ":Grahh! You will never defeat me!");
    }
}
