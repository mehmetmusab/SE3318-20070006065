package com.eldoria;

public class Warrior extends Hero implements Questable {
    public Warrior(String name, int level) {
        super(name, level);
    }

    @Override
    public void acceptQuest(String questName) {
        System.out.println(name + ":A quest has been accepted: " + questName + ".");
    }

    public void attack() {
        System.out.println(name + " swings a mighty sword!");
    }
}
