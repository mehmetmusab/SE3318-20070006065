package com.lotr;

import org.junit.Assert;
import org.junit.Test;
import java.util.List;

/**
 * Smoke tests for Quest class.
 */
public class QuestTest {

    @Test
    public void testCreateAndAddParticipant() {
        Quest q = new Quest("Rescue", 5);
        Character c = new Character("Gimli", "Dwarf", 139, "Warrior");
        q.addParticipant(c);
        List<Character> participants = q.listParticipants();
        Assert.assertTrue(participants.contains(c));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddParticipantNull() {
        Quest q = new Quest("Adventure", 3);
        q.addParticipant(null);
    }
}
