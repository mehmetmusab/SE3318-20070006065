package com.taskmanager;

import java.util.ArrayList;
import java.util.List;

/**
 * Manages assignment of tasks to users.
 */
public class TaskManager {
    /**
     * Assign a task to a user.
     * requires: task != null, user != null
     * effects: adds task to user, if not already present
     */
    public void assignTaskToUser(Task task, User user) {
        if (task == null || user == null) {
            throw new IllegalArgumentException("task and user must be non-null");
        }
        user.addTask(task);
    }

    /**
     * Remove a task from a user's list.
     * requires: task != null, user != null
     * effects: removes task from user if present
     */
    public void removeTaskFromUser(Task task, User user) {
        if (task == null || user == null) {
            throw new IllegalArgumentException("task and user must be non-null");
        }
        user.getTasks().remove(task);
    }

    /**
     * List all tasks assigned to a user.
     * requires: user != null
     * @return list of tasks for that user
     */
    public List<Task> listTasksForUser(User user) {
        if (user == null) {
            return new ArrayList<>();
        }
        return user.getTasks();
    }
}
