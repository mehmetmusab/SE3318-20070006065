package com.ecommerce;

/**
 * Handles payment transactions.
 */
public class PaymentService {

    /**
     * Process payment for a given user.
     * requires: username != null && !username.trim().isEmpty(), amount > 0
     * @return true if payment succeeds, otherwise throws IllegalArgumentException
     */
    public boolean processPayment(String username, double amount) {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username must be non-null and non-empty");
        }
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount must be greater than zero");
        }
        // Simulate payment processing logic (e.g., call to payment gateway)
        System.out.println("Processing payment of $" + amount + " for user '" + username + "'");
        return true;
    }
}
