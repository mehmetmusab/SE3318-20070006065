package com.taskmanager;

import org.junit.Assert;
import org.junit.Test;
import java.time.LocalDate;

public class TaskTest {

    @Test
    public void testCreateValidTask() {
        Task task = new Task("Test Task", LocalDate.now().plusDays(1));
        Assert.assertEquals("Test Task", task.getTitle());
        Assert.assertFalse(task.isCompleted());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateTaskNullTitle() {
        new Task(null, LocalDate.now());
    }

    @Test
    public void testMarkCompleted() {
        Task task = new Task("Task", LocalDate.now().plusDays(1));
        task.markCompleted();
        Assert.assertTrue(task.isCompleted());
    }

    @Test
    public void testIsOverdue() {
        Task task = new Task("Task", LocalDate.now().minusDays(1));
        Assert.assertTrue(task.isOverdue(LocalDate.now()));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testIsOverdueNullDate() {
        Task task = new Task("Task", LocalDate.now().minusDays(1));
        task.isOverdue(null);
    }
}
