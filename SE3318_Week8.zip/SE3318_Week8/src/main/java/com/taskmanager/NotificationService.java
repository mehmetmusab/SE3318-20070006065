package com.taskmanager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Service to handle notifications to users.
 */
public class NotificationService {
    private Map<User, List<String>> notifications;

    /**
     * Construct a new NotificationService.
     * effects: initializes with empty notification map
     */
    public NotificationService() {
        this.notifications = new HashMap<>();
    }

    /**
     * Send a notification message to a user.
     * requires: user != null, message != null && !message.isEmpty()
     * effects: stores message in user's notification list
     */
    public void sendNotification(User user, String message) {
        if (user == null || message == null || message.isEmpty()) {
            throw new IllegalArgumentException("user and message must be non-null/non-empty");
        }
        notifications.computeIfAbsent(user, k -> new ArrayList<>()).add(message);
    }

    /**
     * Retrieve all notifications for a user.
     * requires: user != null
     * @return list of messages, or empty list if none
     */
    public List<String> getNotifications(User user) {
        if (user == null) {
            return new ArrayList<>();
        }
        return notifications.getOrDefault(user, new ArrayList<>());
    }
}
