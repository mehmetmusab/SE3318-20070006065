package com.lotr;

/**
 * Represents a character in The Lord of the Rings universe.
 */
public class Character {
    /**
     * Name of the character.
     */
    private String name;

    /**
     * Race of the character (e.g., Hobbit, Elf, Man, Dwarf).
     */
    private String race;

    /**
     * Age of the character.
     */
    private int age;

    /**
     * Unique attribute for the character (e.g., weapon or title).
     */
    private String uniqueAttribute;

    /**
     * Constructs a new Character.
     * 
     * @param name            name of the character (non-null, non-empty)
     * @param race            race of the character (non-null, non-empty)
     * @param age             age of the character (>= 0)
     * @param uniqueAttribute unique attribute (non-null, non-empty)
     * @throws IllegalArgumentException if parameters invalid
     */
    public Character(final String name, final String race, final int age,
                     final String uniqueAttribute) {
        if (name == null || name.isEmpty()
                || race == null || race.isEmpty()
                || age < 0
                || uniqueAttribute == null || uniqueAttribute.isEmpty()) {
            throw new IllegalArgumentException(
                    "Invalid parameters for Character");
        }
        this.name = name;
        this.race = race;
        this.age = age;
        this.uniqueAttribute = uniqueAttribute;
    }

    /**
     * Gets the name of this character.
     * 
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the race of this character.
     * 
     * @return race
     */
    public String getRace() {
        return race;
    }

    /**
     * Gets the age of this character.
     * 
     * @return age
     */
    public int getAge() {
        return age;
    }

    /**
     * Gets the unique attribute of this character.
     * 
     * @return unique attribute
     */
    public String getUniqueAttribute() {
        return uniqueAttribute;
    }
}
