package com.hogwarts;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

public class SpellbookTest {

    private Spellbook spellbook;

    @Before
    public void setUp() {
        spellbook = new Spellbook();
        // Assume a method to add spells exists, e.g., addSpell or through constructor
        spellbook.getAllSpells().addAll(Arrays.asList("Alohomora", "Expelliarmus", "Lumos", "Accio"));
    }

    @Test
    public void testGetSpellByIndex() {
        String spell = spellbook.getSpell(1);
        Assert.assertEquals("Expelliarmus", spell);
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testGetSpellInvalidIndex() {
        spellbook.getSpell(100);
    }

    @Test
    public void testGetSpellsByPrefixExact() {
        List<String> results = spellbook.getSpellsByPrefix("Alo");
        Assert.assertTrue(results.contains("Alohomora"));
    }

    @Test
    public void testGetSpellsByPrefixEmpty() {
        List<String> results = spellbook.getSpellsByPrefix("");
        Assert.assertEquals(spellbook.getAllSpells().size(), results.size());
    }

    @Test
    public void testGetSpellsByPrefixNoMatch() {
        List<String> results = spellbook.getSpellsByPrefix("XYZ");
        Assert.assertTrue(results.isEmpty());
    }
}
