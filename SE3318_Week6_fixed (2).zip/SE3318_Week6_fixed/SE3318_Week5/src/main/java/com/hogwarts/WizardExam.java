package com.hogwarts;

import java.util.List;

/**
 * WizardExam holds a list of required spells for the exam.
 */
public class WizardExam {
    private List<String> requiredSpells;

    /**
     * Construct a new exam.
     * requires: requiredSpells != null
     * effects: sets the list of spells needed to pass
     * @param requiredSpells list of spells required
     */
    public WizardExam(List<String> requiredSpells) {
        if (requiredSpells == null) {
            throw new IllegalArgumentException("Required spells cannot be null.");
        }
        this.requiredSpells = requiredSpells;
    }

    /**
     * Check if student knows all required spells.
     * requires: student != null
     * @param student HogwartsStudent
     * @return true if student knows all spells, false otherwise
     */
    public boolean pass(HogwartsStudent student) {
        if (student == null) {
            return false;
        }
        for (String spell : requiredSpells) {
            if (!student.knowsSpell(spell)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Print pass/fail result.
     * requires: student != null
     * effects: prints "passed" or "failed"
     * @param student HogwartsStudent
     */
    public void evaluate(HogwartsStudent student) {
        if (student == null) {
            System.out.println("Invalid student.");
            return;
        }
        if (pass(student)) {
            System.out.println(student.getName() + " has passed the exam!");
        } else {
            System.out.println(student.getName() + " has failed the exam.");
        }
    }
}
