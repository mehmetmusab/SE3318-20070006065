package com.middleearth;

public class Main {
    public static void main(String[] args) {
        // Create mentors
        Mentor gandalf = new Mentor("Gandalf", "the Grey");
        Mentor elrond = new Mentor("Elrond", "Lord of Rivendell");

        // Create quests
        Quest destroyRing = new Quest("Destroy the One Ring", 10, gandalf);
        Quest defendHelmsDeep = new Quest("Defend Helm's Deep", 8, elrond);

        // Create adventurers
        Adventurer frodo = new Adventurer("Frodo Baggins", "Hobbit");
        Adventurer aragorn = new Adventurer("Aragorn", "Man");
        Adventurer legolas = new Adventurer("Legolas", "Elf");
        Adventurer gimli = new Adventurer("Gimli", "Dwarf");

        // Adventurers join quests
        frodo.joinQuest(destroyRing);
        aragorn.joinQuest(destroyRing);
        aragorn.joinQuest(defendHelmsDeep);
        legolas.joinQuest(defendHelmsDeep);
        gimli.joinQuest(defendHelmsDeep);

        // Display quest participants
        destroyRing.listAdventurers();
        System.out.println();
        defendHelmsDeep.listAdventurers();
        System.out.println();

        // Display adventurer quest lists
        frodo.listQuests();
        System.out.println();
        aragorn.listQuests();
        System.out.println();

        // Display mentor's quests and guided adventurers
        gandalf.listQuests();
        gandalf.listAdventurers();
        System.out.println();
        elrond.listQuests();
        elrond.listAdventurers();
    }
}
