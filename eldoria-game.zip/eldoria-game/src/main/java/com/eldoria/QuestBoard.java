package com.eldoria;

public class QuestBoard {
    public void assignQuest(Questable character, String questName) {
        character.acceptQuest(questName);
    }
}
