package com.taskmanager;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import java.util.List;

public class NotificationServiceTest {

    private NotificationService ns;
    private User bob;

    @Before
    public void setUp() {
        ns = new NotificationService();
        bob = new User("bob", "b@example.com");
    }

    @Test
    public void testSendAndGetNotifications() {
        ns.sendNotification(bob, "Hello");
        List<String> notes = ns.getNotifications(bob);
        Assert.assertTrue(notes.contains("Hello"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSendInvalidNotification() {
        ns.sendNotification(null, "Hi");
    }

    @Test
    public void testGetNotificationsEmpty() {
        List<String> notes = ns.getNotifications(bob);
        Assert.assertTrue(notes.isEmpty());
    }
}
