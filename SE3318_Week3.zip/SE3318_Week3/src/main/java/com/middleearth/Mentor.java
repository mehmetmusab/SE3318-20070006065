package com.middleearth;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a Mentor who oversees quests and guides adventurers.
 */
public class Mentor extends Character {
    private List<Quest> quests;
    private List<Adventurer> guidedAdventurers;

    public Mentor(String name, String title) {
        super(name, title);
        this.quests = new ArrayList<>();
        this.guidedAdventurers = new ArrayList<>();
    }

    public List<Quest> getQuests() {
        return quests;
    }

    public List<Adventurer> getGuidedAdventurers() {
        return guidedAdventurers;
    }

    public void addQuest(Quest quest) {
        if (quest != null && !quests.contains(quest)) {
            quests.add(quest);
        }
    }

    public void addAdventurer(Adventurer adv) {
        if (adv != null && !guidedAdventurers.contains(adv)) {
            guidedAdventurers.add(adv);
        }
    }

    public void listQuests() {
        System.out.println("Quests overseen by mentor '" + getName() + " the " + getTitle() + "':");
        for (Quest q : quests) {
            System.out.println("- " + q.getName());
        }
    }

    public void listAdventurers() {
        System.out.println("Adventurers guided by '" + getName() + " the " + getTitle() + "':");
        for (Adventurer a : guidedAdventurers) {
            System.out.println("- " + a.getName() + " (" + a.getRace() + ")");
        }
    }
}
