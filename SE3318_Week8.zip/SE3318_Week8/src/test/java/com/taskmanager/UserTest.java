package com.taskmanager;

import org.junit.Assert;
import org.junit.Test;
import java.time.LocalDate;

public class UserTest {

    @Test
    public void testCreateValidUser() {
        User user = new User("john", "john@example.com");
        Assert.assertEquals("john", user.getUsername());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateUserInvalid() {
        new User("", "");
    }

    @Test
    public void testAddTaskAndHasTask() {
        User user = new User("john", "john@example.com");
        Task task = new Task("Task1", LocalDate.now().plusDays(1));
        user.addTask(task);
        Assert.assertTrue(user.hasTask(task));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddNullTask() {
        User user = new User("john", "john@example.com");
        user.addTask(null);
    }
}
