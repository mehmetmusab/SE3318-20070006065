package com.ecommerce;

/**
 * Represents a customer order.
 */
public class Order {
    private Integer orderId;
    private String itemName;
    private int quantity;

    public Order(Integer orderId, String itemName, int quantity) {
        if (orderId == null || orderId <= 0) {
            throw new IllegalArgumentException("Order ID must be non-null and positive");
        }
        if (itemName == null || itemName.trim().isEmpty()) {
            throw new IllegalArgumentException("Item name must be non-null and non-empty");
        }
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }
        this.orderId = orderId;
        this.itemName = itemName;
        this.quantity = quantity;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public String getItemName() {
        return itemName;
    }

    public int getQuantity() {
        return quantity;
    }
}
