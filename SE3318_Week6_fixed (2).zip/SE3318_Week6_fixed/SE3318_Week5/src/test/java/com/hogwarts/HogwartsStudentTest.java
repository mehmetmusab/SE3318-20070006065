package com.hogwarts;

import org.junit.Assert;
import org.junit.Test;

public class HogwartsStudentTest {

    @Test
    public void testLearnValidSpell() {
        HogwartsStudent student = new HogwartsStudent("Harry", "Gryffindor", 3);
        boolean added = student.learnSpell("Alohomora");
        Assert.assertTrue(added);
        Assert.assertTrue(student.knowsSpell("Alohomora"));
    }

    @Test
    public void testLearnNullSpell() {
        HogwartsStudent student = new HogwartsStudent("Harry", "Gryffindor", 3);
        boolean added = student.learnSpell(null);
        Assert.assertFalse(added);
    }

    @Test
    public void testLearnDuplicateSpell() {
        HogwartsStudent student = new HogwartsStudent("Harry", "Gryffindor", 3);
        student.learnSpell("Lumos");
        boolean addedAgain = student.learnSpell("Lumos");
        Assert.assertFalse(addedAgain);
        Assert.assertEquals(1, student.getSpellsLearned().size());
    }

    @Test
    public void testKnowsSpell() {
        HogwartsStudent student = new HogwartsStudent("Harry", "Gryffindor", 3);
        student.learnSpell("Expelliarmus");
        Assert.assertTrue(student.knowsSpell("Expelliarmus"));
        Assert.assertFalse(student.knowsSpell("Wingardium Leviosa"));
    }
}
