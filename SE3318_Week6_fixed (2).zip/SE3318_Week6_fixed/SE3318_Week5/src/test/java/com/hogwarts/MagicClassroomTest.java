package com.hogwarts;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

public class MagicClassroomTest {

    private MagicClassroom classroom;
    private HogwartsStudent harry;
    private HogwartsStudent hermione;

    @Before
    public void setUp() {
        classroom = new MagicClassroom();
        harry = new HogwartsStudent("Harry", "Gryffindor", 3);
        hermione = new HogwartsStudent("Hermione", "Gryffindor", 3);
    }

    @Test
    public void testAddValidStudent() {
        classroom.addStudent(harry);
        List<HogwartsStudent> list = classroom.getStudentsByHouse("Gryffindor");
        Assert.assertTrue(list.contains(harry));
    }

    @Test
    public void testAddNullStudent() {
        classroom.addStudent(null);
        Assert.assertTrue(classroom.getStudentsByHouse("Gryffindor").isEmpty());
    }

    @Test
    public void testFindStudentByName() {
        classroom.addStudent(hermione);
        HogwartsStudent found = classroom.findStudent("Hermione");
        Assert.assertEquals(hermione, found);
    }

    @Test
    public void testFindStudentBySpell() {
        hermione.learnSpell("Wingardium Leviosa");
        classroom.addStudent(hermione);
        HogwartsStudent found = classroom.findStudentBySpell("Wingardium Leviosa");
        Assert.assertEquals(hermione, found);
    }

    @Test
    public void testGetStudentsSortedByHouse() {
        HogwartsStudent draco = new HogwartsStudent("Draco", "Slytherin", 3);
        classroom.addStudent(harry);
        classroom.addStudent(draco);
        List<HogwartsStudent> sorted = classroom.getStudentsSortedByHouse();
        Assert.assertEquals("Gryffindor", sorted.get(0).getHouse());
        Assert.assertEquals("Slytherin", sorted.get(1).getHouse());
    }
}
