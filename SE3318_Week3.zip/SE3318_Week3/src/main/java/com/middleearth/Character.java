package com.middleearth;

/**
 * Abstract superclass for characters in Middle-earth.
 */
public abstract class Character {
    private String name;
    private String title;

    public Character(String name, String title) {
        this.name = name;
        this.title = title;
    }

    public String getName() {
        return name;
    }

    public String getTitle() {
        return title;
    }
}
