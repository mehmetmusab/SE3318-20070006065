package com.hogwarts;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        // Create students
        HogwartsStudent harry = new HogwartsStudent("Harry Potter", "Gryffindor", 3);
        HogwartsStudent draco = new HogwartsStudent("Draco Malfoy", "Slytherin", 3);
        HogwartsStudent hermione = new HogwartsStudent("Hermione Granger", "Gryffindor", 3);

        // Teach spells
        System.out.println("Harry learns Alohomora: " + harry.learnSpell("Alohomora"));
        System.out.println("Draco learns Expelliarmus: " + draco.learnSpell("Expelliarmus"));
        System.out.println("Hermione learns Wingardium Leviosa: " + hermione.learnSpell("Wingardium Leviosa"));
        System.out.println("Harry tries to learn null spell: " + harry.learnSpell(null));

        // Spellbook
        Spellbook book = new Spellbook();
        book.addSpell("Alohomora");
        book.addSpell("Expelliarmus");
        book.addSpell("Wingardium Leviosa");
        book.addSpell("Lumos");
        System.out.println("Spell at index 2: " + book.getSpell(2));
        System.out.println("Spells with prefix 'Alo': " + book.getSpellsByPrefix("Alo"));

        // Classroom
        MagicClassroom classroom = new MagicClassroom();
        classroom.addStudent(harry);
        classroom.addStudent(draco);
        classroom.addStudent(hermione);
        System.out.println("Find student by name 'Draco Malfoy': " + classroom.findStudentByName("Draco Malfoy"));
        System.out.println("Find student by spell 'Wingardium Leviosa': " + classroom.findStudentBySpell("Wingardium Leviosa"));
        System.out.println("Students in Gryffindor: " + classroom.getStudentsByHouse("Gryffindor"));
        System.out.println("All students sorted by house: " + classroom.getStudentsSortedByHouse());

        // Wizard Exam
        WizardExam exam = new WizardExam(Arrays.asList("Alohomora", "Expelliarmus"));
        exam.evaluate(harry);
        exam.evaluate(draco);

        // Duels
        Duel.start(harry, draco, "Alohomora");
        Duel.start(hermione, draco, "Wingardium Leviosa");
    }
}
