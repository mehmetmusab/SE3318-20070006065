package com.eldoria;

public class Hero extends Character {
    public Hero(String name, int level) {
        super(name, level);
    }

    @Override
    public void speak() {
        System.out.println(name + ":I am ready for my next quest!");
    }
}
