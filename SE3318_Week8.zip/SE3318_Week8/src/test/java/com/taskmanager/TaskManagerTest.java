package com.taskmanager;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import java.time.LocalDate;
import java.util.List;

public class TaskManagerTest {

    private TaskManager tm;
    private User charlie;
    private Task task;

    @Before
    public void setUp() {
        tm = new TaskManager();
        charlie = new User("charlie", "c@example.com");
        task = new Task("TaskX", LocalDate.now().plusDays(2));
    }

    @Test
    public void testAssignAndListTasks() {
        tm.assignTaskToUser(task, charlie);
        List<Task> tasks = tm.listTasksForUser(charlie);
        Assert.assertTrue(tasks.contains(task));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAssignNull() {
        tm.assignTaskToUser(null, charlie);
    }

    @Test
    public void testRemoveTask() {
        tm.assignTaskToUser(task, charlie);
        tm.removeTaskFromUser(task, charlie);
        Assert.assertFalse(charlie.hasTask(task));
    }
}
