# Eldoria Game

## Project Structure
- **Character** (abstract class): Represents any game character. Has a name and level. Requires a method `speak()`.
- **Hero** (class): Inherits from `Character`. Represents playable characters.
- **Enemy** (class): Inherits from `Character`. Represents game enemies.
- **Questable** (interface): Characters that can accept quests must implement this. It includes `acceptQuest(String questName)`.
- **QuestBoard** (class): Assigns quests to characters that implement `Questable`.
- **BattleManager** (class): Simulates a battle between a `Hero` and an `Enemy`.
- **Mage** (class): Extends `Hero`, implements `Questable`, adds method `castSpell()`.
- **Warrior** (class): Extends `Hero`, implements `Questable`, adds method `attack()`.

## Sample Output
```
Gandalf: "A quest has been accepted: Defeat the Shadowlord."
Aragorn: "A quest has been accepted: Protect the village."
Battle starts between Aragorn (Level 10) and Orc (Level 8).
Aragorn attacks Orc for 15 damage.
Orc attacks Aragorn for 10 damage.
...
```

## Git Workflow
1. Create a new branch `Week-6`.
2. Commit changes using the format: `<Type> - <Issue/Story Number>: <Short Description>`.
   - Example: `Feature - #302: Created Mage character with castSpell()`
3. Push the `Week-6` branch to GitHub.
4. Tag the final version:
   - Tag name: `v1.0-eldoria-core`
