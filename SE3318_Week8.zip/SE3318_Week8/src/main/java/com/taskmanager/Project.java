package com.taskmanager;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a Project containing users and tasks.
 */
public class Project {
    private String name;
    private List<User> users;
    private List<Task> tasks;

    /**
     * Construct a new Project.
     * requires: name != null && !name.isEmpty()
     * effects: initializes with empty user and task lists
     */
    public Project(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("name must be non-null/non-empty");
        }
        this.name = name;
        this.users = new ArrayList<>();
        this.tasks = new ArrayList<>();
    }

    /**
     * Add a user to the project.
     * requires: user != null && not already in project
     * effects: adds user to users list
     */
    public void addUser(User user) {
        if (user == null) {
            throw new IllegalArgumentException("user must be non-null");
        }
        if (!users.contains(user)) {
            users.add(user);
        }
    }

    /**
     * Assign a task to the project.
     * requires: task != null && not already in project
     * effects: adds task to tasks list
     */
    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("task must be non-null");
        }
        if (!tasks.contains(task)) {
            tasks.add(task);
        }
    }

    /**
     * Retrieve a task by its title.
     * requires: title != null
     * @return task with matching title, or null if not found
     */
    public Task getTaskByTitle(String title) {
        if (title == null) {
            return null;
        }
        for (Task t : tasks) {
            if (title.equals(t.getTitle())) {
                return t;
            }
        }
        return null;
    }

    /**
     * @return list of users in this project
     */
    public List<User> getUsers() {
        return users;
    }

    /**
     * @return list of tasks in this project
     */
    public List<Task> getTasks() {
        return tasks;
    }
}
