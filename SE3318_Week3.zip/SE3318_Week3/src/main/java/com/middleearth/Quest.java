package com.middleearth;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a Quest in Middle-earth.
 */
public class Quest {
    private String name;
    private int difficultyLevel;
    private Mentor mentor;
    private List<Adventurer> adventurers;

    public Quest(String name, int difficultyLevel, Mentor mentor) {
        this.name = name;
        this.difficultyLevel = difficultyLevel;
        this.mentor = mentor;
        this.adventurers = new ArrayList<>();
        if (mentor != null) {
            mentor.addQuest(this);
        }
    }

    public String getName() {
        return name;
    }

    public int getDifficultyLevel() {
        return difficultyLevel;
    }

    public Mentor getMentor() {
        return mentor;
    }

    public List<Adventurer> getAdventurers() {
        return adventurers;
    }

    public void addAdventurer(Adventurer adv) {
        if (adv != null && !adventurers.contains(adv)) {
            adventurers.add(adv);
            if (mentor != null) {
                mentor.addAdventurer(adv);
            }
        }
    }

    public void listAdventurers() {
        System.out.println("Adventurers on quest '" + name + "':");
        for (Adventurer a : adventurers) {
            System.out.println("- " + a.getName() + " (" + a.getRace() + ")");
        }
    }
}
