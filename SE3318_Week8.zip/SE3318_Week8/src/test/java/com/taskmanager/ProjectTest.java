package com.taskmanager;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import java.time.LocalDate;

public class ProjectTest {

    private Project project;
    private User alice;
    private Task task;

    @Before
    public void setUp() {
        project = new Project("Proj");
        alice = new User("alice", "a@example.com");
        task = new Task("T1", LocalDate.now().plusDays(1));
    }

    @Test
    public void testAddUserAndTask() {
        project.addUser(alice);
        project.addTask(task);
        Assert.assertTrue(project.getUsers().contains(alice));
        Assert.assertTrue(project.getTasks().contains(task));
    }

    @Test
    public void testGetTaskByTitle() {
        project.addTask(task);
        Task found = project.getTaskByTitle("T1");
        Assert.assertEquals(task, found);
    }

    @Test
    public void testGetTaskByTitleNotFound() {
        Assert.assertNull(project.getTaskByTitle("None"));
    }
}
