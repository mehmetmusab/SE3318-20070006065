package com.taskmanager;

import java.time.LocalDate;

/**
 * Main class to demonstrate Task Management System.
 */
public class Main {
    public static void main(String[] args) {
        // Create tasks
        Task task1 = new Task("Design Module", LocalDate.now().plusDays(3));
        Task task2 = new Task("Implement Feature", LocalDate.now().plusDays(7));

        // Create users
        User alice = new User("alice", "alice@example.com");
        User bob = new User("bob", "bob@example.com");

        // Add tasks to users
        TaskManager tm = new TaskManager();
        tm.assignTaskToUser(task1, alice);
        tm.assignTaskToUser(task2, bob);

        // Create project
        Project project = new Project("Migration Project");
        project.addUser(alice);
        project.addUser(bob);
        project.addTask(task1);
        project.addTask(task2);

        // Notification service
        NotificationService ns = new NotificationService();
        ns.sendNotification(alice, "New task assigned: Design Module");
        ns.sendNotification(bob, "New task assigned: Implement Feature");

        // Display notifications
        System.out.println("Alice's notifications: " + ns.getNotifications(alice));
        System.out.println("Bob's notifications: " + ns.getNotifications(bob));

        // Check overdue
        System.out.println("Is 'Design Module' overdue? " + task1.isOverdue(LocalDate.now().plusDays(5)));

        // List tasks for Alice
        System.out.println("Alice's tasks: " + tm.listTasksForUser(alice));
    }
}
