package com.taskmanager;

import java.time.LocalDate;

/**
 * Represents a Task in the system.
 */
public class Task {
    private String title;
    private LocalDate dueDate;
    private boolean completed;

    /**
     * Construct a new Task.
     * requires: title != null && !title.isEmpty(), dueDate != null
     * effects: initializes task with given title, dueDate, and completed = false
     */
    public Task(String title, LocalDate dueDate) {
        if (title == null || title.isEmpty() || dueDate == null) {
            throw new IllegalArgumentException("Title and dueDate must be non-null/non-empty");
        }
        this.title = title;
        this.dueDate = dueDate;
        this.completed = false;
    }

    /**
     * @return the title of the task
     */
    public String getTitle() {
        return title;
    }

    /**
     * @return the due date of the task
     */
    public LocalDate getDueDate() {
        return dueDate;
    }

    /**
     * @return true if the task is marked as completed
     */
    public boolean isCompleted() {
        return completed;
    }

    /**
     * Mark the task as completed.
     * requires: task is not already completed.
     * effects: sets completed = true
     */
    public void markCompleted() {
        if (!this.completed) {
            this.completed = true;
        }
    }

    /**
     * Determine if the task is overdue.
     * requires: currentDate != null
     * @param currentDate the date to compare against
     * @return true if currentDate is after dueDate and not completed
     */
    public boolean isOverdue(LocalDate currentDate) {
        if (currentDate == null) {
            throw new IllegalArgumentException("currentDate must be non-null");
        }
        return !completed && currentDate.isAfter(dueDate);
    }
}
