package com.ecommerce;

/**
 * Processes orders with validation and error handling.
 */
public class OrderProcessor {

    /**
     * Process the given order.
     * requires: order != null
     * effects: validates order fields and prints confirmation, otherwise throws IllegalArgumentException
     */
    public void processOrder(Order order) {
        if (order == null) {
            throw new IllegalArgumentException("Order cannot be null");
        }
        if (order.getItemName() == null || order.getItemName().trim().isEmpty()) {
            throw new IllegalArgumentException("Item name is invalid");
        }
        if (order.getQuantity() <= 0) {
            throw new IllegalArgumentException("Quantity must be greater than zero");
        }
        // Simulate processing logic
        System.out.println("Processing order ID " + order.getOrderId()
                + " for item '" + order.getItemName()
                + "' (quantity: " + order.getQuantity() + ")");
    }
}
