package com.lotr;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a quest in The Lord of the Rings universe.
 */
public class Quest {
    /**
     * Type of this quest (e.g., Adventure, Rescue).
     */
    private String type;

    /**
     * Difficulty level of the quest (1-10).
     */
    private int difficulty;

    /**
     * Participants in this quest.
     */
    private List<Character> participants;

    /**
     * Constructs a new Quest.
     * 
     * @param type       type of quest (non-null, non-empty)
     * @param difficulty difficulty level (1-10)
     * @throws IllegalArgumentException if parameters invalid
     */
    public Quest(final String type, final int difficulty) {
        if (type == null || type.isEmpty() || difficulty < 1
                || difficulty > 10) {
            throw new IllegalArgumentException("Invalid parameters for Quest");
        }
        this.type = type;
        this.difficulty = difficulty;
        this.participants = new ArrayList<>();
    }

    /**
     * Adds a participant to this quest.
     * 
     * @param character character to add (non-null)
     * @throws IllegalArgumentException if character null
     */
    public void addParticipant(final Character character) {
        if (character == null) {
            throw new IllegalArgumentException("Participant cannot be null");
        }
        if (!participants.contains(character)) {
            participants.add(character);
        }
    }

    /**
     * Lists all participants in this quest.
     * 
     * @return unmodifiable list of participants
     */
    public List<Character> listParticipants() {
        return new ArrayList<>(participants);
    }

    /**
     * Gets the difficulty of this quest.
     * 
     * @return difficulty
     */
    public int getDifficulty() {
        return difficulty;
    }

    /**
     * Gets the type of this quest.
     * 
     * @return type
     */
    public String getType() {
        return type;
    }
}
