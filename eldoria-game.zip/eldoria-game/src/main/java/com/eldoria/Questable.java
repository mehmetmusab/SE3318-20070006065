package com.eldoria;

public interface Questable {
    void acceptQuest(String questName);
}
