package com.hogwarts;

import java.util.Random;

/**
 * Simulates a duel between two students using a single spell.
 */
public class Duel {
    private static Random random = new Random();

    /**
     * Starts a duel.
     * requires: s1 != null, s2 != null, spell != null
     * effects: prints the outcome of the duel
     * @param s1 first student
     * @param s2 second student
     * @param spell spell used
     */
    public static void start(HogwartsStudent s1, HogwartsStudent s2, String spell) {
        if (s1 == null || s2 == null || spell == null) {
            System.out.println("Invalid duel parameters.");
            return;
        }
        boolean knows1 = s1.knowsSpell(spell);
        boolean knows2 = s2.knowsSpell(spell);

        if (!knows1 && !knows2) {
            System.out.println("It's a draw! Neither knows " + spell);
        } else if (knows1 && !knows2) {
            System.out.println(s1.getName() + " wins! " + s2.getName() + " doesn't know " + spell);
        } else if (!knows1 && knows2) {
            System.out.println(s2.getName() + " wins! " + s1.getName() + " doesn't know " + spell);
        } else {
            // both know, random strength
            int strength1 = random.nextInt(100);
            int strength2 = random.nextInt(100);
            if (strength1 > strength2) {
                System.out.println(s1.getName() + " wins the duel with strength " + strength1 + " vs " + strength2);
            } else if (strength2 > strength1){
                System.out.println(s2.getName() + " wins the duel with strength " + strength2 + " vs " + strength1);
            } else {
                System.out.println("It's a tie with both strength " + strength1);
            }
        }
    }
}
