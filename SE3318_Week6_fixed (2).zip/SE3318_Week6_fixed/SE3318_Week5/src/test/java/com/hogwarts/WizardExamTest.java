package com.hogwarts;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;

public class WizardExamTest {

    private WizardExam exam;
    private HogwartsStudent harry;
    private HogwartsStudent draco;

    @Before
    public void setUp() {
        exam = new WizardExam(Arrays.asList("Alohomora", "Expelliarmus"));
        harry = new HogwartsStudent("Harry", "Gryffindor", 3);
        draco = new HogwartsStudent("Draco", "Slytherin", 3);
        harry.learnSpell("Alohomora");
        harry.learnSpell("Expelliarmus");
    }

    @Test
    public void testPassTrue() {
        Assert.assertTrue(exam.pass(harry));
    }

    @Test
    public void testPassFalse() {
        Assert.assertFalse(exam.pass(draco));
    }
}
