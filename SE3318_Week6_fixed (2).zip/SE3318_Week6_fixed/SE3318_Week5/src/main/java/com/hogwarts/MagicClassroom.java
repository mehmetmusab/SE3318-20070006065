package com.hogwarts;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Holds many students and provides operations.
 */
public class MagicClassroom {
    private List<HogwartsStudent> students;

    /**
     * Construct a new classroom.
     * effects: initializes with empty student list.
     */
    public MagicClassroom() {
        students = new ArrayList<>();
    }

    /**
     * Add a new student to the classroom.
     * requires: student != null
     * effects: if student not null and not already present, adds to list
     */
    public void addStudent(HogwartsStudent student) {
        if (student != null) {
            students.add(student);
        }
    }

    /**
     * Find a student by name.
     * requires: name not null
     * @return first student with matching name, or null if none found
     */
    public HogwartsStudent findStudentByName(String name) {
        if (name == null) {
            return null;
        }
        for (HogwartsStudent s : students) {
            if (name.equals(s.getName())) {
                return s;
            }
        }
        return null;
    }

    /**
     * Find a student who knows a specific spell.
     * requires: spell not null
     * @return first student who knows the spell, or null if none found
     */
    public HogwartsStudent findStudentBySpell(String spell) {
        if (spell == null) {
            return null;
        }
        for (HogwartsStudent s : students) {
            if (s.knowsSpell(spell)) {
                return s;
            }
        }
        return null;
    }

    /**
     * List all students in a specific house.
     * requires: house not null
     * @return list of students whose house matches the given house
     */
    public List<HogwartsStudent> getStudentsByHouse(String house) {
        List<HogwartsStudent> result = new ArrayList<>();
        if (house == null) {
            return result;
        }
        for (HogwartsStudent s : students) {
            if (house.equals(s.getHouse())) {
                result.add(s);
            }
        }
        return result;
    }

    /**
     * Show all students sorted by house.
     * @return sorted list by house name
     */
    public List<HogwartsStudent> getStudentsSortedByHouse() {
        List<HogwartsStudent> copy = new ArrayList<>(students);
        copy.sort(Comparator.comparing(HogwartsStudent::getHouse));
        return copy;
    }
}
