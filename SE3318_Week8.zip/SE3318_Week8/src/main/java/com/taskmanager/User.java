package com.taskmanager;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a User in the system.
 */
public class User {
    private String username;
    private String email;
    private List<Task> tasks;

    /**
     * Construct a new User.
     * requires: username != null && !username.isEmpty(), email != null && !email.isEmpty()
     * effects: initializes user with empty task list
     */
    public User(String username, String email) {
        if (username == null || username.isEmpty() || email == null || email.isEmpty()) {
            throw new IllegalArgumentException("username and email must be non-null/non-empty");
        }
        this.username = username;
        this.email = email;
        this.tasks = new ArrayList<>();
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @return the email address
     */
    public String getEmail() {
        return email;
    }

    /**
     * Add a task to the user's list.
     * requires: task != null && task not already in tasks
     * effects: adds the task to tasks list
     */
    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("task must be non-null");
        }
        if (!tasks.contains(task)) {
            tasks.add(task);
        }
    }

    /**
     * Check if user has a specific task.
     * requires: task != null
     * @return true if task is in user's list
     */
    public boolean hasTask(Task task) {
        if (task == null) {
            return false;
        }
        return tasks.contains(task);
    }

    /**
     * @return list of all tasks assigned to this user
     */
    public List<Task> getTasks() {
        return tasks;
    }
}
